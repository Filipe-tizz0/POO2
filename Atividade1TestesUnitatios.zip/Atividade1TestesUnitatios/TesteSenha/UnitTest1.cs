using Xunit;
using AulaTestes;
using System;

namespace AulaTestes.Tests
{
    public class TesteSenha
    {
        [Theory]
        [InlineData("Senha123", true)]
        [InlineData("12345678", false)]
        [InlineData("", false)]
        [InlineData("abcdEFGH", false)]

        public void Somar_DeveRetornarResultadoCorreto(string senha, bool result)
        {
            // Arrange
            ValidadorSenha Validator = new ValidadorSenha();
            // Act
            var resultado = Validator.EhValida(senha);
            // Assert
            Assert.Equal(result, resultado);
        }
    }
}