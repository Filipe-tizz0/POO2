﻿using AulaTestes;

string senha = Console.ReadLine();

ValidadorSenha val_senha = new ValidadorSenha();

bool flag = val_senha.EhValida(senha);
if (flag)
{
    Console.WriteLine("Senha valida");
} else
{
    Console.WriteLine("Senha inválida");
}